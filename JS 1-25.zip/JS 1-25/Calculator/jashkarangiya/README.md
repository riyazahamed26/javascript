# Calculator
 - A simple calculator using HTML, CSS, and JS <br>
 - It has a dark-mode theme as well as a light-mode theme. <br>
 - It can calculate some of the basic operations like addition, subtraction, multiplication, and division. <br>

 ## Built using:

 - HTML
 - CSS
 - Javascript 
 
 ## Preview
 - You can get the preview on <a href="https://jashkarangiya.github.io/calculator/" target="_blank">Calculator</a>
