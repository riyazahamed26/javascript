# Annoying Button Game

Buttons are annoying when they seem to be moving around!

This is a game where you have to find the correct button out of all the buttons before the timer finishes.

How to play:

1. Click the start button.
2. Click all the buttons until you win.
