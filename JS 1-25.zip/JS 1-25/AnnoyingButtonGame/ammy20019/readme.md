## Catch me if you can


### Using HTML, CSS & JS
##### you can find screenshot in this folder

## Screeen shot: https://github.com/ammy20019/javascript-mini-projects/blob/master/CatchMeIfYouCan/ammy20019/screenshot.PNG
