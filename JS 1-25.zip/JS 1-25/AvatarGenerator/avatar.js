$(document).ready(function() {
  $(".clickme").on("click", function() {
      let name = $("#nameid").val();
      if (name) {
          // Generate avatar based on the name, keeping the current image displayed
          // For now, we just alert the user
          alert("Avatar generated for " + name + "!");
      } else {
          alert("Please enter your name.");
      }
  });

  $(".light").on("click", function() {
      $("body").removeClass("dark-mode").addClass("light-mode");
  });

  $(".dark").on("click", function() {
      $("body").removeClass("light-mode").addClass("dark-mode");
  });
});
