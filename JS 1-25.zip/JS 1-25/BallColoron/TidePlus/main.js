const game = {
    start: function() {
        document.getElementById('start-game').style.display = 'none';
        // Add other game start logic here
    },
    intro: function() {
        document.getElementById('start-game').style.display = 'flex';
        // Add other intro logic here
    },
    generateTweet: function() {
        // Add tweet generation logic here
    }
};

// Example function to initialize the game interface
window.onload = function() {
    document.getElementById('start-game').style.display = 'flex';
};
