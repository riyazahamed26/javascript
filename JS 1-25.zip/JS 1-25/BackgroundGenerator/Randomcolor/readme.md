## Linear-colour-Gradient

### Javascript Linear-colour-Gradient

This project is a javascript based Product. It allows you to click a cell and make a random Linear Gradient at random degree with random colours . Also number of colours are also not specific so a user can generate linear-Gradient with any number of colours 