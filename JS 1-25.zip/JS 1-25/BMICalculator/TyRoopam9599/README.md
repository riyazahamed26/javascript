
# BMI Calculator

- Created a BMI Calculator using HTML, CSS, and JavaScript.
- The Calculator takes the input of your height(in cms or In), and your weight(in kg or lb) and gives BMI as the output.
- It's easy to use, you can use it to calculate your BMI. 


## Features

- Easy to use
- Great interface
- Created just by using basic HTML, CSS, and JavaScript code
- Give class on the basis of BMI result



## Demo 
[Video](https://github.com/TyRoopam9599/javascript-mini-projects/assets/91320513/7162945d-55cb-4e1a-a5bd-b6dd65cb7f10)

![Screenshot](https://github.com/TyRoopam9599/javascript-mini-projects/assets/91320513/4865629c-b9d1-4501-9848-252d9a846ba6)
