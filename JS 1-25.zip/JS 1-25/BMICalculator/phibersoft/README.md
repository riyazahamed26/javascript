# BMI Calculator

This is a simple BMI calculator that takes in the user's height and weight and calculates their BMI. It also gives a
brief description of the user's BMI.

## Images

<div style="display: flex; flex-direction: row;">
  <img src="./assets/bmi_calculator_initial.png" alt="BMI Calculator Initial" height="400" style="margin-right: 20px" />
  <img src="./assets/bmi_calculator_status.png" alt="BMI Calculator Result" height="400" />
</div>
